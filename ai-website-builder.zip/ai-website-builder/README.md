# ⚡ AI Website Builder — Complete SaaS Platform

> **Dunya ka sabse powerful AI website builder** — ek prompt likhein, poori website tayar!

---

## 🚀 Platform Overview

Yeh platform in features ke sath aata hai:

| Feature | Status |
|---|---|
| AI Website Generation (Claude) | ✅ |
| User Auth (JWT — No Firebase) | ✅ |
| Built-in Hosting (FastAPI serves sites) | ✅ |
| Automatic Subdomain | ✅ |
| 1-Click Deploy | ✅ |
| Custom Domain Support | ✅ |
| Built-in Analytics | ✅ |
| Site Regeneration | ✅ |
| Beautiful Dashboard UI | ✅ |
| SQLite DB (No PostgreSQL needed) | ✅ |

---

## 🏗️ Architecture

```
User writes prompt
       ↓
FastAPI receives request
       ↓
Claude AI analyzes prompt → decides site type, name, structure
       ↓
Claude AI generates complete HTML/CSS/JS (single file)
       ↓
HTML saved to /sites/{slug}.html
       ↓
User clicks "Deploy" → site goes LIVE
       ↓
Accessible at: http://localhost:8000/s/{subdomain}
(Production:   https://{subdomain}.yourdomain.com)
```

---

## 📁 Project Structure

```
ai-website-builder/
├── backend/
│   ├── main.py              ← FastAPI app entry point
│   ├── database.py          ← SQLite models (User, Site, Generation)
│   ├── schemas.py           ← Pydantic request/response schemas
│   ├── auth.py              ← JWT authentication (no Firebase!)
│   ├── ai_generator.py      ← Claude AI integration (THE BRAIN)
│   ├── requirements.txt     ← Python dependencies
│   ├── .env                 ← Config (API keys, domain, etc.)
│   └── routers/
│       ├── auth_router.py   ← /api/auth/* (login, register, me)
│       ├── sites_router.py  ← /api/sites/* (generate, deploy, etc.)
│       └── public_router.py ← /s/{subdomain} (serve live sites)
├── frontend/
│   └── index.html           ← Complete dashboard UI (single file!)
├── sites/                   ← Generated HTML files stored here
└── start.sh                 ← Quick start script
```

---

## ⚡ Quick Start

### 1. Get Anthropic API Key
Go to https://console.anthropic.com and create an API key.

### 2. Configure .env
```bash
cd backend
nano .env
# Set: ANTHROPIC_API_KEY=sk-ant-your-key-here
# Set: BASE_DOMAIN=localhost  (or yourdomain.com in production)
```

### 3. Run
```bash
# Linux/Mac
chmod +x start.sh && ./start.sh

# Windows
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### 4. Open Dashboard
```
http://localhost:8000
```

Default login:
- Email: `admin@aibuilder.com`
- Password: `admin123`

---

## 🔌 API Endpoints

### Auth
```
POST /api/auth/register   → Register new user
POST /api/auth/login      → Login, get JWT token
GET  /api/auth/me         → Get current user info
```

### Sites (JWT required)
```
POST /api/sites/generate          → 🧠 AI generates website from prompt
GET  /api/sites                   → List all user's sites
GET  /api/sites/{id}              → Get site details + HTML
POST /api/sites/{id}/deploy       → 🚀 1-click deploy
POST /api/sites/{id}/undeploy     → Take site offline
POST /api/sites/{id}/regenerate   → Regenerate with new prompt
GET  /api/sites/{id}/preview      → HTML preview (for iframe)
POST /api/sites/{id}/domain       → Add custom domain
GET  /api/sites/{id}/analytics    → View count, stats
DELETE /api/sites/{id}            → Delete site
```

### Public
```
GET /s/{subdomain}   → Serve live site
GET /health          → Health check
GET /api/stats       → Platform stats
```

---

## 🌍 Production Deployment

### 1. Server Setup (Ubuntu/VPS)
```bash
# Install Python
sudo apt update && sudo apt install python3-pip python3-venv nginx certbot -y

# Clone project
git clone your-repo /var/www/aibuilder
cd /var/www/aibuilder/backend

# Setup
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 2. Update .env for Production
```env
BASE_DOMAIN=yourdomain.com
SECRET_KEY=<random 256-bit string>
ANTHROPIC_API_KEY=sk-ant-your-key
```

### 3. Nginx Config (Wildcard Subdomain)
```nginx
server {
    listen 80;
    server_name yourdomain.com *.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### 4. SSL (Let's Encrypt)
```bash
# Requires DNS provider that supports wildcard certs
certbot --nginx -d yourdomain.com -d *.yourdomain.com
```

### 5. Run with Gunicorn
```bash
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

---

## 💡 How AI Generation Works

1. **Prompt Analysis** (claude-opus-4-5)
   - Detects site type (ecommerce, portfolio, blog, etc.)
   - Chooses site name if not provided
   - Decides sections, features, color scheme

2. **Website Generation** (claude-opus-4-5, 8000 tokens)
   - Generates complete HTML + CSS + JS in one file
   - Real content (not lorem ipsum)
   - Mobile responsive
   - Smooth animations
   - Working forms and interactions

3. **Post-Processing**
   - Injects analytics tracking script
   - Saves to disk
   - Updates database

---

## 🔧 Extending the Platform

### Add Stripe Payments
```python
# In routers/sites_router.py, add plan upgrade endpoint
# Use stripe Python library
import stripe
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")
```

### Add Email (SMTP — no SendGrid needed)
```python
import smtplib
# Configure in .env: SMTP_HOST, SMTP_USER, SMTP_PASS
```

### Upgrade to PostgreSQL
```python
# In database.py, change:
DATABASE_URL = "postgresql://user:pass@localhost/aibuilder"
# Remove check_same_thread from engine args
```

---

## 🎯 Supported Site Types

| Type | What AI Builds |
|---|---|
| 🛒 E-commerce | Product grid, cart, checkout, categories |
| 💼 Portfolio | Hero, projects gallery, skills, contact |
| 📰 Blog | Posts grid, categories, newsletter |
| 🚀 Landing | Hero, features, pricing, CTA |
| 🍕 Restaurant | Menu tabs, reservation form, gallery |
| ⚙️ SaaS | Features, pricing tiers, integrations |
| 🏢 Agency | Services, portfolio, team, case studies |
| 🏠 Real Estate | Property listings, search, contact |
| 📚 Education | Courses, instructors, testimonials |
| 🎉 Event | Schedule, speakers, tickets, countdown |

---

Built with ❤️ using FastAPI + Anthropic Claude + Pure HTML/CSS/JS
