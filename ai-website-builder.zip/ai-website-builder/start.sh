#!/bin/bash
# ============================================
#   AI Website Builder — Quick Start Script
# ============================================

set -e  # Exit on error

echo ""
echo "⚡ AI Website Builder Setup"
echo "================================"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required. Install from https://python.org"
    exit 1
fi

echo "✅ Python found: $(python3 --version)"

# Create virtual environment
cd backend

if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate venv
source venv/bin/activate

echo "📥 Installing dependencies..."
pip install -r requirements.txt --quiet

# Check .env file
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "⚠️  Created .env file — please add your ANTHROPIC_API_KEY"
fi

# Check API key
if grep -q "your_anthropic_api_key_here" .env; then
    echo ""
    echo "⚠️  WARNING: ANTHROPIC_API_KEY not set in backend/.env"
    echo "   Get your key from: https://console.anthropic.com"
    echo "   Then edit backend/.env and replace 'your_anthropic_api_key_here'"
    echo ""
fi

echo ""
echo "🚀 Starting server..."
echo "   Dashboard: http://localhost:8000"
echo "   API Docs:  http://localhost:8000/docs"
echo ""
echo "   Default Admin Login:"
echo "   Email: admin@aibuilder.com"
echo "   Password: admin123"
echo ""

python3 -m uvicorn main:app --reload --host 0.0.0.0 --port 8000
