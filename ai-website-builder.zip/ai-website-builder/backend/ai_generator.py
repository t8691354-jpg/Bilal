"""
AI Website Generator — The Heart of the Platform
Uses Claude (Anthropic) to generate complete, production-ready websites
from a single natural language prompt.
"""

import anthropic
import os
import re
import json
import unicodedata
from dotenv import load_dotenv

load_dotenv()

client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))


# ─────────────────────────────────────────────
#  Site Type Detection Prompt
# ─────────────────────────────────────────────

SITE_ANALYSIS_PROMPT = """You are an expert website architect. Analyze this request and return ONLY a JSON object (no markdown, no explanation).

User request: "{prompt}"

Return this exact JSON structure:
{{
  "site_type": "<one of: ecommerce, portfolio, blog, landing, restaurant, agency, saas, nonprofit, education, healthcare, real_estate, event, other>",
  "site_name": "<creative business/site name if user didn't specify one>",
  "site_slug": "<url-friendly slug, lowercase, hyphens only, max 30 chars>",
  "description": "<one line description of what this site does>",
  "ai_decision_notes": "<brief explanation of what you decided to build and why>",
  "color_scheme": "<primary hex color>",
  "style": "<modern|minimal|bold|elegant|playful>",
  "sections": ["<list of page sections to include>"],
  "features": ["<list of key features to build>"]
}}"""


# ─────────────────────────────────────────────
#  Master Website Generation Prompt
# ─────────────────────────────────────────────

WEBSITE_GENERATION_PROMPT = """You are the world's most advanced AI website builder. Generate a COMPLETE, PRODUCTION-READY, SINGLE-FILE HTML website.

## User Request:
{prompt}

## Site Specifications:
- Type: {site_type}
- Name: {site_name}
- Style: {style}
- Color Scheme: {color_scheme}
- Sections: {sections}
- Features: {features}

## CRITICAL REQUIREMENTS:

1. **SINGLE FILE**: Everything in ONE .html file (HTML + CSS + JS). No external files.
2. **FULLY FUNCTIONAL**: All buttons, forms, navigation must work perfectly.
3. **RESPONSIVE**: Mobile-first, works on all screen sizes.
4. **BEAUTIFUL DESIGN**: Professional, modern UI. Not generic. Use gradients, animations, proper typography.
5. **COMPLETE CONTENT**: Real, meaningful placeholder content. Not "Lorem ipsum". Write actual relevant content.
6. **ANIMATIONS**: Smooth scroll animations, hover effects, transitions.
7. **WORKING FEATURES**:
   - Navigation with smooth scroll
   - Mobile hamburger menu
   - Contact forms with validation (show success message)
   - Scroll-to-top button
   - Loading animations

## SPECIFIC REQUIREMENTS BY TYPE:

**ecommerce**: Product grid with Add to Cart, shopping cart sidebar, checkout form, product categories, search bar, product cards with hover effects, price filters.

**portfolio**: Hero with name/title, animated skills section, project gallery with modal popups, testimonials, contact form, social links.

**blog**: Hero, featured posts grid, category filter, newsletter signup, sidebar with recent posts, author bio.

**landing**: Powerful hero with CTA, features section, pricing table, testimonials, FAQ accordion, final CTA, footer.

**restaurant**: Full-width hero, menu with tabs (Starters/Mains/Desserts/Drinks), reservation form with date/time picker, gallery lightbox, hours & location.

**saas**: Hero with demo video placeholder, feature highlights, pricing tiers (Free/Pro/Enterprise), integration logos, testimonials slider.

**agency**: Cinematic hero, services grid with icons, portfolio grid with case studies, team section, client logos, contact form.

## DESIGN STANDARDS:
- Use CSS custom properties (variables) for theming
- Google Fonts (load via @import in CSS)
- SVG icons (inline, no icon library needed)
- CSS Grid + Flexbox layouts
- Glassmorphism or neumorphism effects where appropriate
- Micro-interactions on all interactive elements
- Dark/light sections alternating for visual interest

## OUTPUT:
Return ONLY the complete HTML. Start with <!DOCTYPE html>. No explanations, no markdown, no backticks.
The HTML must be complete and valid. Every tag must be closed. No broken JavaScript.
"""


# ─────────────────────────────────────────────
#  Main Generation Functions
# ─────────────────────────────────────────────

async def analyze_prompt(prompt: str) -> dict:
    """
    Step 1: Analyze the prompt and decide what kind of site to build.
    This makes the AI 'smart' — it understands intent automatically.
    """
    try:
        message = client.messages.create(
            model="claude-opus-4-5",
            max_tokens=1000,
            messages=[{
                "role": "user",
                "content": SITE_ANALYSIS_PROMPT.format(prompt=prompt)
            }]
        )

        response_text = message.content[0].text.strip()

        # Clean up JSON if needed
        response_text = re.sub(r'^```json\s*', '', response_text)
        response_text = re.sub(r'\s*```$', '', response_text)

        analysis = json.loads(response_text)

        # Ensure slug is URL-safe
        analysis["site_slug"] = make_slug(analysis.get("site_slug", analysis.get("site_name", "my-site")))

        return analysis

    except json.JSONDecodeError:
        # Fallback if JSON parsing fails
        return {
            "site_type": "landing",
            "site_name": "My Awesome Site",
            "site_slug": "my-awesome-site",
            "description": "A beautiful website",
            "ai_decision_notes": "Built as a landing page",
            "color_scheme": "#6366f1",
            "style": "modern",
            "sections": ["hero", "features", "contact"],
            "features": ["responsive design", "contact form", "smooth animations"]
        }


async def generate_website(prompt: str, analysis: dict) -> dict:
    """
    Step 2: Generate the complete website HTML.
    Returns the HTML content and token usage.
    """
    sections_str = ", ".join(analysis.get("sections", []))
    features_str = ", ".join(analysis.get("features", []))

    generation_prompt = WEBSITE_GENERATION_PROMPT.format(
        prompt=prompt,
        site_type=analysis.get("site_type", "landing"),
        site_name=analysis.get("site_name", "My Site"),
        style=analysis.get("style", "modern"),
        color_scheme=analysis.get("color_scheme", "#6366f1"),
        sections=sections_str,
        features=features_str
    )

    message = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=8000,
        messages=[{
            "role": "user",
            "content": generation_prompt
        }]
    )

    html_content = message.content[0].text.strip()

    # Remove any accidental markdown code blocks
    html_content = re.sub(r'^```html\s*', '', html_content)
    html_content = re.sub(r'^```\s*', '', html_content)
    html_content = re.sub(r'\s*```$', '', html_content)

    # Ensure it starts with DOCTYPE
    if not html_content.startswith("<!DOCTYPE"):
        idx = html_content.find("<!DOCTYPE")
        if idx > 0:
            html_content = html_content[idx:]

    return {
        "html": html_content,
        "tokens_used": message.usage.input_tokens + message.usage.output_tokens
    }


async def regenerate_website(prompt: str, site_type: str, site_name: str) -> dict:
    """
    Regenerate a website with a new prompt (for the update feature).
    Faster — skips the analysis step.
    """
    analysis = {
        "site_type": site_type,
        "site_name": site_name,
        "style": "modern",
        "color_scheme": "#6366f1",
        "sections": ["hero", "features", "about", "contact"],
        "features": ["responsive", "animations", "contact form"]
    }
    return await generate_website(prompt, analysis)


# ─────────────────────────────────────────────
#  Utilities
# ─────────────────────────────────────────────

def make_slug(text: str) -> str:
    """Convert any text to a URL-safe slug"""
    # Normalize unicode
    text = unicodedata.normalize('NFKD', text)
    text = text.encode('ascii', 'ignore').decode('ascii')
    # Lowercase
    text = text.lower()
    # Replace spaces and underscores with hyphens
    text = re.sub(r'[\s_]+', '-', text)
    # Remove non-alphanumeric (except hyphens)
    text = re.sub(r'[^a-z0-9-]', '', text)
    # Remove leading/trailing hyphens
    text = text.strip('-')
    # Truncate
    return text[:40] or "my-site"


def inject_tracking_script(html: str, site_id: int, base_url: str) -> str:
    """
    Inject a tiny analytics tracking script into the generated HTML.
    Counts page views without any third-party service.
    """
    tracking_script = f"""
    <script>
    // AI Website Builder - Built-in Analytics
    (function() {{
        fetch('{base_url}/api/sites/{site_id}/track', {{
            method: 'POST',
            headers: {{'Content-Type': 'application/json'}},
            body: JSON.stringify({{
                referrer: document.referrer,
                ua: navigator.userAgent.substring(0, 100)
            }})
        }}).catch(()=>{{}});
    }})();
    </script>
    """

    # Inject before </body>
    if "</body>" in html:
        html = html.replace("</body>", tracking_script + "\n</body>")
    else:
        html += tracking_script

    return html


def add_builder_badge(html: str) -> str:
    """Add a small 'Built with AI Builder' badge (optional)"""
    badge = """
    <div style="position:fixed;bottom:16px;right:16px;z-index:9999;
                background:rgba(0,0,0,0.75);color:white;padding:6px 12px;
                border-radius:20px;font-size:12px;font-family:sans-serif;
                backdrop-filter:blur(8px);display:flex;align-items:center;gap:6px;">
      ⚡ Built with AI Builder
    </div>
    """
    if "</body>" in html:
        html = html.replace("</body>", badge + "\n</body>")
    return html
