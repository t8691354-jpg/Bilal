"""
Sites Router — Core of the platform
POST /api/sites/generate    — AI generates a full website from prompt
GET  /api/sites             — List user's sites
GET  /api/sites/{id}        — Get site details + HTML
PUT  /api/sites/{id}        — Update site settings
DELETE /api/sites/{id}      — Delete site
POST /api/sites/{id}/deploy — 1-click deploy
POST /api/sites/{id}/regenerate — Regenerate with new prompt
GET  /api/sites/{id}/preview    — Preview the generated HTML
POST /api/sites/{id}/domain     — Add custom domain
POST /api/sites/{id}/track      — Analytics tracking
"""

import os
import re
import asyncio
from datetime import datetime
from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from dotenv import load_dotenv

from database import get_db, Site, Generation, User, SiteStatus, PlanType, CustomDomain
import schemas
import auth as auth_utils
import ai_generator as ai

load_dotenv()

router = APIRouter(prefix="/api/sites", tags=["Sites"])

BASE_DOMAIN = os.getenv("BASE_DOMAIN", "localhost")
PORT        = os.getenv("PORT", "8000")
SITES_DIR   = Path(os.getenv("SITES_DIR", "../sites"))
MAX_FREE    = int(os.getenv("MAX_SITES_FREE", "3"))

# Ensure sites directory exists
SITES_DIR.mkdir(parents=True, exist_ok=True)


# ─────────────────────────────────────────────
#  Helper: build site URL
# ─────────────────────────────────────────────

def build_site_url(subdomain: str) -> str:
    if BASE_DOMAIN == "localhost":
        return f"http://localhost:{PORT}/s/{subdomain}"
    return f"https://{subdomain}.{BASE_DOMAIN}"


def unique_slug(base_slug: str, db: Session) -> str:
    slug = base_slug
    counter = 1
    while db.query(Site).filter(Site.slug == slug).first():
        slug = f"{base_slug}-{counter}"
        counter += 1
    return slug


def unique_subdomain(username: str, slug: str, db: Session) -> str:
    base = f"{username}-{slug}"[:50]
    sub = base
    counter = 1
    while db.query(Site).filter(Site.subdomain == sub).first():
        sub = f"{base}-{counter}"
        counter += 1
    return sub


# ─────────────────────────────────────────────
#  GENERATE SITE (Main AI endpoint)
# ─────────────────────────────────────────────

@router.post("/generate", response_model=schemas.SiteDetail, status_code=201)
async def generate_site(
    request: schemas.GenerateSiteRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    """
    🚀 THE MAIN ENDPOINT
    User sends a prompt → AI analyzes intent → Generates full website → Returns HTML
    """

    # Check plan limits
    user_site_count = db.query(Site).filter(Site.owner_id == current_user.id).count()
    if current_user.plan == PlanType.FREE and user_site_count >= MAX_FREE:
        raise HTTPException(
            status_code=403,
            detail=f"Free plan allows max {MAX_FREE} sites. Upgrade to Pro for unlimited sites."
        )

    # Step 1: AI analyzes the prompt
    try:
        analysis = await ai.analyze_prompt(request.prompt)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI analysis failed: {str(e)}")

    # Override site name if user specified one
    if request.site_name:
        analysis["site_name"] = request.site_name
        analysis["site_slug"] = ai.make_slug(request.site_name)

    # Ensure unique slug and subdomain
    final_slug = unique_slug(analysis["site_slug"], db)
    final_subdomain = unique_subdomain(current_user.username, final_slug, db)

    # Step 2: Create DB record (status = GENERATING)
    site = Site(
        owner_id=current_user.id,
        name=analysis["site_name"],
        slug=final_slug,
        description=analysis.get("description", ""),
        original_prompt=request.prompt,
        site_type=analysis.get("site_type", "landing"),
        ai_notes=analysis.get("ai_decision_notes", ""),
        status=SiteStatus.GENERATING,
        subdomain=final_subdomain,
    )
    db.add(site)
    db.commit()
    db.refresh(site)

    # Step 3: AI generates the full website HTML
    try:
        result = await ai.generate_website(request.prompt, analysis)
        html_content = result["html"]
        tokens_used  = result["tokens_used"]
    except Exception as e:
        site.status = SiteStatus.FAILED
        db.commit()
        raise HTTPException(status_code=500, detail=f"Website generation failed: {str(e)}")

    # Step 4: Inject analytics tracking
    base_url = f"http://localhost:{PORT}"
    html_content = ai.inject_tracking_script(html_content, site.id, base_url)

    # Step 5: Save HTML to disk
    html_filename = f"{final_slug}.html"
    html_path = SITES_DIR / html_filename
    html_path.write_text(html_content, encoding="utf-8")

    # Step 6: Save generation record
    gen = Generation(
        site_id=site.id,
        prompt=request.prompt,
        html_content=html_content,
        version=1,
        tokens_used=tokens_used
    )
    db.add(gen)

    # Step 7: Update site record
    site.status   = SiteStatus.DRAFT
    site.html_file = str(html_path)
    db.commit()
    db.refresh(site)

    # Return full response with HTML
    site_resp = schemas.SiteDetail.model_validate(site)
    site_resp.html_content = html_content
    return site_resp


# ─────────────────────────────────────────────
#  LIST USER SITES
# ─────────────────────────────────────────────

@router.get("", response_model=List[schemas.SiteResponse])
def list_sites(
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    """Get all sites belonging to the current user"""
    sites = db.query(Site).filter(Site.owner_id == current_user.id).order_by(Site.created_at.desc()).all()
    return sites


# ─────────────────────────────────────────────
#  GET SITE DETAILS
# ─────────────────────────────────────────────

@router.get("/{site_id}", response_model=schemas.SiteDetail)
def get_site(
    site_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    """Get site details including HTML content"""
    site = db.query(Site).filter(
        Site.id == site_id,
        Site.owner_id == current_user.id
    ).first()

    if not site:
        raise HTTPException(status_code=404, detail="Site not found")

    site_resp = schemas.SiteDetail.model_validate(site)

    # Load HTML content from disk
    if site.html_file and Path(site.html_file).exists():
        site_resp.html_content = Path(site.html_file).read_text(encoding="utf-8")

    return site_resp


# ─────────────────────────────────────────────
#  1-CLICK DEPLOY
# ─────────────────────────────────────────────

@router.post("/{site_id}/deploy", response_model=schemas.DeployResponse)
def deploy_site(
    site_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    """
    🚀 1-Click Deploy
    Makes the site publicly accessible at its subdomain URL.
    """
    site = db.query(Site).filter(
        Site.id == site_id,
        Site.owner_id == current_user.id
    ).first()

    if not site:
        raise HTTPException(status_code=404, detail="Site not found")

    if site.status == SiteStatus.GENERATING:
        raise HTTPException(status_code=400, detail="Site is still being generated")

    if not site.html_file or not Path(site.html_file).exists():
        raise HTTPException(status_code=400, detail="No HTML file found. Please generate the site first.")

    # Mark as deployed
    site.status      = SiteStatus.DEPLOYED
    site.is_live     = True
    site.deployed_at = datetime.utcnow()
    db.commit()
    db.refresh(site)

    site_url = build_site_url(site.subdomain)

    return schemas.DeployResponse(
        success=True,
        message=f"🎉 Site '{site.name}' is now live!",
        url=site_url,
        subdomain=site.subdomain
    )


# ─────────────────────────────────────────────
#  UNDEPLOY (Take offline)
# ─────────────────────────────────────────────

@router.post("/{site_id}/undeploy")
def undeploy_site(
    site_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    site = db.query(Site).filter(Site.id == site_id, Site.owner_id == current_user.id).first()
    if not site:
        raise HTTPException(status_code=404, detail="Site not found")

    site.status  = SiteStatus.DRAFT
    site.is_live = False
    db.commit()

    return {"message": "Site taken offline. Deploy again to make it live."}


# ─────────────────────────────────────────────
#  REGENERATE SITE
# ─────────────────────────────────────────────

@router.post("/{site_id}/regenerate", response_model=schemas.SiteDetail)
async def regenerate_site(
    site_id: int,
    request: schemas.RegenerateSiteRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    """Regenerate a site with a new or modified prompt"""
    site = db.query(Site).filter(
        Site.id == site_id,
        Site.owner_id == current_user.id
    ).first()

    if not site:
        raise HTTPException(status_code=404, detail="Site not found")

    # Deactivate old generations
    db.query(Generation).filter(Generation.site_id == site_id).update({"is_active": False})

    # Get current version number
    latest_version = db.query(Generation).filter(Generation.site_id == site_id).count()

    # Generate new HTML
    site.status = SiteStatus.GENERATING
    db.commit()

    try:
        result = await ai.regenerate_website(request.prompt, site.site_type, site.name)
        html_content = result["html"]
        tokens_used  = result["tokens_used"]
    except Exception as e:
        site.status = SiteStatus.DRAFT
        db.commit()
        raise HTTPException(status_code=500, detail=f"Regeneration failed: {str(e)}")

    # Add tracking
    base_url = f"http://localhost:{PORT}"
    html_content = ai.inject_tracking_script(html_content, site.id, base_url)

    # Save new HTML
    html_path = SITES_DIR / f"{site.slug}.html"
    html_path.write_text(html_content, encoding="utf-8")

    # Save new generation
    gen = Generation(
        site_id=site.id,
        prompt=request.prompt,
        html_content=html_content,
        version=latest_version + 1,
        tokens_used=tokens_used
    )
    db.add(gen)

    # Update site
    site.original_prompt = request.prompt
    site.html_file = str(html_path)
    site.status    = SiteStatus.DRAFT
    site.is_live   = False  # Need to redeploy
    db.commit()
    db.refresh(site)

    site_resp = schemas.SiteDetail.model_validate(site)
    site_resp.html_content = html_content
    return site_resp


# ─────────────────────────────────────────────
#  PREVIEW SITE (Iframe-able)
# ─────────────────────────────────────────────

@router.get("/{site_id}/preview", response_class=HTMLResponse)
def preview_site(
    site_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    """Return raw HTML for iframe preview in dashboard"""
    site = db.query(Site).filter(
        Site.id == site_id,
        Site.owner_id == current_user.id
    ).first()

    if not site:
        raise HTTPException(status_code=404, detail="Site not found")

    if site.html_file and Path(site.html_file).exists():
        html = Path(site.html_file).read_text(encoding="utf-8")
        return HTMLResponse(content=html)

    return HTMLResponse(content="<html><body><h1>Site not generated yet</h1></body></html>")


# ─────────────────────────────────────────────
#  ADD CUSTOM DOMAIN
# ─────────────────────────────────────────────

@router.post("/{site_id}/domain", response_model=schemas.CustomDomainResponse)
def add_custom_domain(
    site_id: int,
    request: schemas.CustomDomainRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    """Add a custom domain to a site"""

    # Pro/Agency only
    if current_user.plan == PlanType.FREE:
        raise HTTPException(
            status_code=403,
            detail="Custom domains require Pro plan or higher. Upgrade to add your domain."
        )

    site = db.query(Site).filter(
        Site.id == site_id,
        Site.owner_id == current_user.id
    ).first()

    if not site:
        raise HTTPException(status_code=404, detail="Site not found")

    # Check domain not already taken
    existing = db.query(Site).filter(Site.custom_domain == request.domain).first()
    if existing and existing.id != site_id:
        raise HTTPException(status_code=400, detail="This domain is already in use")

    # Update site
    site.custom_domain = request.domain
    db.commit()

    server_ip = "YOUR_SERVER_IP"  # Would be real IP in production

    return schemas.CustomDomainResponse(
        domain=request.domain,
        verified=False,
        site_id=site_id,
        dns_instructions=(
            f"To connect your domain, add this DNS record:\n\n"
            f"Type: A\n"
            f"Name: @ (or your domain root)\n"
            f"Value: {server_ip}\n"
            f"TTL: 3600\n\n"
            f"Or for CNAME:\n"
            f"Type: CNAME\n"
            f"Name: www\n"
            f"Value: {site.subdomain}.{BASE_DOMAIN}\n\n"
            f"DNS changes may take up to 24-48 hours to propagate."
        )
    )


# ─────────────────────────────────────────────
#  UPDATE SITE SETTINGS
# ─────────────────────────────────────────────

@router.put("/{site_id}", response_model=schemas.SiteResponse)
def update_site(
    site_id: int,
    request: schemas.UpdateSiteRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    site = db.query(Site).filter(
        Site.id == site_id,
        Site.owner_id == current_user.id
    ).first()

    if not site:
        raise HTTPException(status_code=404, detail="Site not found")

    if request.name:
        site.name = request.name
    if request.custom_domain is not None:
        site.custom_domain = request.custom_domain or None

    db.commit()
    db.refresh(site)
    return site


# ─────────────────────────────────────────────
#  DELETE SITE
# ─────────────────────────────────────────────

@router.delete("/{site_id}")
def delete_site(
    site_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    site = db.query(Site).filter(
        Site.id == site_id,
        Site.owner_id == current_user.id
    ).first()

    if not site:
        raise HTTPException(status_code=404, detail="Site not found")

    # Delete HTML file from disk
    if site.html_file:
        try:
            Path(site.html_file).unlink(missing_ok=True)
        except:
            pass

    db.delete(site)
    db.commit()

    return {"message": f"Site '{site.name}' deleted successfully"}


# ─────────────────────────────────────────────
#  ANALYTICS TRACKING
# ─────────────────────────────────────────────

@router.post("/{site_id}/track")
def track_view(site_id: int, db: Session = Depends(get_db)):
    """Track a page view (called by injected script in generated sites)"""
    site = db.query(Site).filter(Site.id == site_id, Site.is_live == True).first()
    if site:
        site.view_count += 1
        db.commit()
    return {"ok": True}


# ─────────────────────────────────────────────
#  ANALYTICS SUMMARY
# ─────────────────────────────────────────────

@router.get("/{site_id}/analytics", response_model=schemas.SiteAnalytics)
def get_analytics(
    site_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth_utils.get_current_user)
):
    site = db.query(Site).filter(
        Site.id == site_id,
        Site.owner_id == current_user.id
    ).first()

    if not site:
        raise HTTPException(status_code=404, detail="Site not found")

    return schemas.SiteAnalytics(
        site_id=site.id,
        site_name=site.name,
        view_count=site.view_count,
        status=site.status,
        is_live=site.is_live,
        created_at=site.created_at,
        deployed_at=site.deployed_at
    )
