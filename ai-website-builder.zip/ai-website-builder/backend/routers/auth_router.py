"""
Authentication Routes
POST /api/auth/register
POST /api/auth/login
GET  /api/auth/me
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from datetime import timedelta

from database import get_db, User
import schemas
import auth as auth_utils

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.post("/register", response_model=schemas.Token, status_code=201)
def register(user_data: schemas.UserRegister, db: Session = Depends(get_db)):
    """Register a new user account"""

    # Check if email already exists
    if auth_utils.get_user_by_email(db, user_data.email):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )

    # Check if username already taken
    if auth_utils.get_user_by_username(db, user_data.username):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already taken"
        )

    # Create user
    new_user = User(
        email=user_data.email,
        username=user_data.username,
        hashed_password=auth_utils.hash_password(user_data.password),
        full_name=user_data.full_name
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Generate token
    token = auth_utils.create_access_token(
        data={"sub": str(new_user.id)},
        expires_delta=timedelta(days=7)
    )

    return schemas.Token(
        access_token=token,
        token_type="bearer",
        user=schemas.UserResponse.model_validate(new_user)
    )


@router.post("/login", response_model=schemas.Token)
def login(credentials: schemas.UserLogin, db: Session = Depends(get_db)):
    """Login and get JWT token"""

    user = auth_utils.authenticate_user(db, credentials.email, credentials.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )

    token = auth_utils.create_access_token(
        data={"sub": str(user.id)},
        expires_delta=timedelta(days=7)
    )

    return schemas.Token(
        access_token=token,
        token_type="bearer",
        user=schemas.UserResponse.model_validate(user)
    )


@router.get("/me", response_model=schemas.UserResponse)
def get_me(current_user: User = Depends(auth_utils.get_current_user)):
    """Get current user profile"""
    return current_user


@router.post("/logout")
def logout():
    """
    JWT is stateless — client just deletes the token.
    This endpoint exists for frontend compatibility.
    """
    return {"message": "Logged out successfully"}
