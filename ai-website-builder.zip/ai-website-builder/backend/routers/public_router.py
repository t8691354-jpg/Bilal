"""
Public Site Serving Router
Serves deployed sites at:
  - /s/{subdomain}  — subdomain-style access (works on localhost)
  - Custom domain routing handled by middleware

In production, set up Nginx/Caddy to proxy subdomain requests
to this FastAPI app, and the middleware handles the rest.
"""

import os
from pathlib import Path
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from database import SessionLocal, Site, SiteStatus

router = APIRouter(tags=["Public Sites"])

SITES_DIR = Path(os.getenv("SITES_DIR", "../sites"))


def get_db():
    db = SessionLocal()
    try:
        return db
    finally:
        pass  # Keep open for this request, we close manually


# ─────────────────────────────────────────────
#  Serve site by subdomain path (localhost dev)
# ─────────────────────────────────────────────

@router.get("/s/{subdomain}", response_class=HTMLResponse)
async def serve_site_by_path(subdomain: str, request: Request):
    """
    Serve a deployed site by its subdomain.
    In development: http://localhost:8000/s/johndoe-my-store
    In production:  https://johndoe-my-store.yourdomain.com
    """
    db = SessionLocal()
    try:
        site = db.query(Site).filter(
            Site.subdomain == subdomain,
            Site.is_live == True
        ).first()

        if not site:
            return HTMLResponse(
                content=_not_found_page(subdomain),
                status_code=404
            )

        # Increment view count
        site.view_count += 1
        db.commit()

        # Serve HTML
        if site.html_file and Path(site.html_file).exists():
            html = Path(site.html_file).read_text(encoding="utf-8")
            return HTMLResponse(content=html)

        return HTMLResponse(content=_error_page(), status_code=500)

    finally:
        db.close()


# ─────────────────────────────────────────────
#  Middleware-based custom domain serving
# ─────────────────────────────────────────────

async def serve_by_custom_domain(request: Request) -> HTMLResponse | None:
    """
    Called by middleware to check if request host is a custom domain.
    Returns HTML response if found, None otherwise.
    """
    host = request.headers.get("host", "").split(":")[0].lower()

    # Skip known paths
    if not host or host in ("localhost", "127.0.0.1"):
        return None

    db = SessionLocal()
    try:
        site = db.query(Site).filter(
            Site.custom_domain == host,
            Site.is_live == True
        ).first()

        if not site:
            return None

        site.view_count += 1
        db.commit()

        if site.html_file and Path(site.html_file).exists():
            html = Path(site.html_file).read_text(encoding="utf-8")
            return HTMLResponse(content=html)

        return None

    finally:
        db.close()


# ─────────────────────────────────────────────
#  Error Pages
# ─────────────────────────────────────────────

def _not_found_page(subdomain: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Site Not Found</title>
  <style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      text-align: center;
    }}
    .container {{ max-width: 500px; padding: 40px; }}
    .emoji {{ font-size: 80px; margin-bottom: 20px; }}
    h1 {{ font-size: 2rem; margin-bottom: 12px; }}
    p {{ color: rgba(255,255,255,0.7); margin-bottom: 30px; font-size: 1.1rem; }}
    a {{
      background: #6366f1;
      color: white;
      padding: 12px 28px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: 600;
    }}
    a:hover {{ background: #4f46e5; }}
    .code {{
      background: rgba(255,255,255,0.1);
      padding: 8px 16px;
      border-radius: 6px;
      font-family: monospace;
      font-size: 0.9rem;
      margin: 16px 0;
    }}
  </style>
</head>
<body>
  <div class="container">
    <div class="emoji">🔍</div>
    <h1>Site Not Found</h1>
    <div class="code">{subdomain}</div>
    <p>This site doesn't exist or hasn't been deployed yet.</p>
    <a href="/">Build Your Own Website →</a>
  </div>
</body>
</html>"""


def _error_page() -> str:
    return """<!DOCTYPE html>
<html><head><title>Error</title></head>
<body style="font-family:sans-serif;text-align:center;padding:80px;">
  <h1>⚠️ Something went wrong</h1>
  <p>The site files could not be found. Please contact support.</p>
</body></html>"""
