"""
🚀 AI Website Builder — Main FastAPI Application
The most powerful AI website builder platform

Run: uvicorn main:app --reload --port 8000
"""

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

from database import create_tables, SessionLocal, Site
from routers.auth_router   import router as auth_router
from routers.sites_router  import router as sites_router
from routers.public_router import router as public_router, serve_by_custom_domain

load_dotenv()

BASE_DOMAIN = os.getenv("BASE_DOMAIN", "localhost")
PORT        = os.getenv("PORT", "8000")
SITES_DIR   = Path(os.getenv("SITES_DIR", "../sites"))
FRONTEND_DIR = Path("../frontend")


# ─────────────────────────────────────────────
#  Startup / Shutdown
# ─────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print("🚀 AI Website Builder starting up...")
    create_tables()
    SITES_DIR.mkdir(parents=True, exist_ok=True)

    # Create default admin user if not exists
    _create_admin_if_needed()

    print(f"✅ Database ready")
    print(f"✅ Sites directory: {SITES_DIR.absolute()}")
    print(f"✅ Server running at: http://localhost:{PORT}")
    print(f"✅ API docs at: http://localhost:{PORT}/docs")
    yield

    # Shutdown
    print("👋 AI Website Builder shutting down...")


def _create_admin_if_needed():
    """Create admin user on first startup"""
    from database import User
    from auth import hash_password

    db = SessionLocal()
    try:
        admin_email = os.getenv("ADMIN_EMAIL", "admin@aibuilder.com")
        admin_pass  = os.getenv("ADMIN_PASSWORD", "admin123")

        existing = db.query(User).filter(User.email == admin_email).first()
        if not existing:
            admin = User(
                email=admin_email,
                username="admin",
                hashed_password=hash_password(admin_pass),
                full_name="Admin User",
                is_admin=True
            )
            db.add(admin)
            db.commit()
            print(f"✅ Admin user created: {admin_email}")
    finally:
        db.close()


# ─────────────────────────────────────────────
#  App Instance
# ─────────────────────────────────────────────

app = FastAPI(
    title="AI Website Builder",
    description="🚀 Build any website with a single prompt. The world's most powerful AI website builder.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)


# ─────────────────────────────────────────────
#  CORS Middleware
# ─────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],     # In production: specify your frontend domains
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────
#  Custom Domain Middleware
#  Checks if request host is a user's custom domain
# ─────────────────────────────────────────────

@app.middleware("http")
async def custom_domain_middleware(request: Request, call_next):
    # Try to serve by custom domain
    host = request.headers.get("host", "").split(":")[0].lower()

    # Only intercept non-API, non-local requests
    if (host not in ("localhost", "127.0.0.1") and
        not request.url.path.startswith("/api") and
        not request.url.path.startswith("/docs") and
        not request.url.path.startswith("/redoc") and
        not request.url.path.startswith("/s/") and
        not request.url.path.startswith("/static") and
        "." in host):

        response = await serve_by_custom_domain(request)
        if response:
            return response

    return await call_next(request)


# ─────────────────────────────────────────────
#  Include Routers
# ─────────────────────────────────────────────

app.include_router(auth_router)
app.include_router(sites_router)
app.include_router(public_router)


# ─────────────────────────────────────────────
#  Static Files (Frontend)
# ─────────────────────────────────────────────

if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")


# ─────────────────────────────────────────────
#  Root — Serve Dashboard
# ─────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the frontend dashboard"""
    frontend_index = FRONTEND_DIR / "index.html"
    if frontend_index.exists():
        return HTMLResponse(content=frontend_index.read_text())

    # Fallback welcome page
    return HTMLResponse(content=_welcome_page())


# ─────────────────────────────────────────────
#  Health Check
# ─────────────────────────────────────────────

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "version": "1.0.0",
        "platform": "AI Website Builder",
        "base_domain": BASE_DOMAIN
    }


# ─────────────────────────────────────────────
#  Platform Stats (Public)
# ─────────────────────────────────────────────

@app.get("/api/stats")
async def platform_stats():
    db = SessionLocal()
    try:
        from database import User, Site
        total_users = db.query(User).count()
        total_sites = db.query(Site).count()
        live_sites  = db.query(Site).filter(Site.is_live == True).count()
        return {
            "total_users": total_users,
            "total_sites": total_sites,
            "live_sites": live_sites,
            "platform": "AI Website Builder v1.0"
        }
    finally:
        db.close()


# ─────────────────────────────────────────────
#  Welcome Page Fallback
# ─────────────────────────────────────────────

def _welcome_page() -> str:
    return """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI Website Builder</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      text-align: center;
    }
    .container { max-width: 600px; padding: 40px; }
    .logo { font-size: 64px; margin-bottom: 20px; }
    h1 { font-size: 2.5rem; margin-bottom: 16px; background: linear-gradient(90deg, #6366f1, #8b5cf6, #ec4899); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    p { color: rgba(255,255,255,0.7); font-size: 1.2rem; margin-bottom: 32px; }
    .links { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; }
    a { padding: 12px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; transition: all 0.2s; }
    .primary { background: linear-gradient(90deg, #6366f1, #8b5cf6); color: white; }
    .secondary { border: 2px solid rgba(255,255,255,0.3); color: white; }
    a:hover { transform: translateY(-2px); opacity: 0.9; }
    .badge { background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); padding: 6px 16px; border-radius: 20px; font-size: 0.85rem; display: inline-block; margin-bottom: 24px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo">⚡</div>
    <div class="badge">🟢 Server is running</div>
    <h1>AI Website Builder</h1>
    <p>Build any website with a single prompt. The most powerful AI website builder platform.</p>
    <div class="links">
      <a href="/docs" class="primary">📖 API Documentation</a>
      <a href="/redoc" class="secondary">📚 ReDoc</a>
      <a href="/health" class="secondary">💓 Health Check</a>
    </div>
  </div>
</body>
</html>"""


# ─────────────────────────────────────────────
#  Run directly
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(PORT),
        reload=True,
        log_level="info"
    )
