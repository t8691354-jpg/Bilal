"""
Database configuration and models for AI Website Builder
Uses SQLite with SQLAlchemy - No external database needed!
"""

from sqlalchemy import (
    create_engine, Column, Integer, String,
    Boolean, DateTime, Text, ForeignKey, Enum
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import enum

# SQLite database - stored locally, no setup needed
DATABASE_URL = "sqlite:///./ai_website_builder.db"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}  # Required for SQLite
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# ─────────────────────────────────────────────
#  Enums
# ─────────────────────────────────────────────

class SiteStatus(str, enum.Enum):
    GENERATING = "generating"
    DRAFT      = "draft"
    DEPLOYED   = "deployed"
    FAILED     = "failed"

class PlanType(str, enum.Enum):
    FREE    = "free"
    PRO     = "pro"
    AGENCY  = "agency"


# ─────────────────────────────────────────────
#  Models
# ─────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id            = Column(Integer, primary_key=True, index=True)
    email         = Column(String(255), unique=True, index=True, nullable=False)
    username      = Column(String(50),  unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name     = Column(String(100))
    plan          = Column(Enum(PlanType), default=PlanType.FREE)
    is_active     = Column(Boolean, default=True)
    is_admin      = Column(Boolean, default=False)
    created_at    = Column(DateTime, default=datetime.utcnow)
    updated_at    = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    sites = relationship("Site", back_populates="owner", cascade="all, delete-orphan")


class Site(Base):
    __tablename__ = "sites"

    id            = Column(Integer, primary_key=True, index=True)
    owner_id      = Column(Integer, ForeignKey("users.id"), nullable=False)
    name          = Column(String(100), nullable=False)
    slug          = Column(String(100), unique=True, index=True, nullable=False)
    description   = Column(Text)

    # AI Generation
    original_prompt = Column(Text, nullable=False)
    site_type       = Column(String(50))   # ecommerce, portfolio, blog, landing, etc.
    ai_notes        = Column(Text)         # What AI decided to build

    # Deployment
    status        = Column(Enum(SiteStatus), default=SiteStatus.DRAFT)
    subdomain     = Column(String(100), unique=True, index=True)  # auto-generated
    custom_domain = Column(String(255), unique=True, index=True)  # user can add
    html_file     = Column(String(500))    # path to generated HTML file
    is_live       = Column(Boolean, default=False)

    # Analytics
    view_count    = Column(Integer, default=0)

    # Timestamps
    created_at    = Column(DateTime, default=datetime.utcnow)
    updated_at    = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deployed_at   = Column(DateTime)

    # Relationships
    owner = relationship("User", back_populates="sites")
    generations = relationship("Generation", back_populates="site", cascade="all, delete-orphan")


class Generation(Base):
    __tablename__ = "generations"

    id          = Column(Integer, primary_key=True, index=True)
    site_id     = Column(Integer, ForeignKey("sites.id"), nullable=False)
    prompt      = Column(Text, nullable=False)
    html_content = Column(Text)           # The generated HTML
    version     = Column(Integer, default=1)
    tokens_used = Column(Integer, default=0)
    is_active   = Column(Boolean, default=True)
    created_at  = Column(DateTime, default=datetime.utcnow)

    site = relationship("Site", back_populates="generations")


class CustomDomain(Base):
    __tablename__ = "custom_domains"

    id         = Column(Integer, primary_key=True, index=True)
    site_id    = Column(Integer, ForeignKey("sites.id"), nullable=False)
    domain     = Column(String(255), unique=True, index=True, nullable=False)
    verified   = Column(Boolean, default=False)
    ssl_active = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


# ─────────────────────────────────────────────
#  DB Dependency for FastAPI routes
# ─────────────────────────────────────────────

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_tables():
    """Create all tables if they don't exist"""
    Base.metadata.create_all(bind=engine)
