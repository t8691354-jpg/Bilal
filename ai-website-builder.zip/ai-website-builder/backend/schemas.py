"""
Pydantic schemas for request/response validation
"""

from pydantic import BaseModel, EmailStr, field_validator
from typing import Optional, List
from datetime import datetime
from database import SiteStatus, PlanType


# ─────────────────────────────────────────────
#  Auth Schemas
# ─────────────────────────────────────────────

class UserRegister(BaseModel):
    email: EmailStr
    username: str
    password: str
    full_name: Optional[str] = None

    @field_validator("username")
    def username_alphanumeric(cls, v):
        if not v.replace("-", "").replace("_", "").isalnum():
            raise ValueError("Username must be alphanumeric (hyphens/underscores allowed)")
        if len(v) < 3 or len(v) > 30:
            raise ValueError("Username must be 3-30 characters")
        return v.lower()

    @field_validator("password")
    def password_strength(cls, v):
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserResponse"


class UserResponse(BaseModel):
    id: int
    email: str
    username: str
    full_name: Optional[str]
    plan: PlanType
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ─────────────────────────────────────────────
#  Site / Project Schemas
# ─────────────────────────────────────────────

class GenerateSiteRequest(BaseModel):
    """Main request to generate a site from a prompt"""
    prompt: str
    site_name: Optional[str] = None  # If None, AI will decide

    @field_validator("prompt")
    def prompt_not_empty(cls, v):
        if len(v.strip()) < 5:
            raise ValueError("Prompt must be at least 5 characters")
        if len(v) > 2000:
            raise ValueError("Prompt must be under 2000 characters")
        return v.strip()


class RegenerateSiteRequest(BaseModel):
    prompt: str
    keep_name: bool = True


class SiteResponse(BaseModel):
    id: int
    name: str
    slug: str
    description: Optional[str]
    original_prompt: str
    site_type: Optional[str]
    ai_notes: Optional[str]
    status: SiteStatus
    subdomain: Optional[str]
    custom_domain: Optional[str]
    is_live: bool
    view_count: int
    created_at: datetime
    deployed_at: Optional[datetime]

    class Config:
        from_attributes = True


class SiteDetail(SiteResponse):
    """Extended response with HTML content"""
    html_content: Optional[str] = None


class DeployResponse(BaseModel):
    success: bool
    message: str
    url: str
    subdomain: str


class CustomDomainRequest(BaseModel):
    domain: str

    @field_validator("domain")
    def validate_domain(cls, v):
        v = v.lower().strip()
        if v.startswith("http://") or v.startswith("https://"):
            v = v.split("//")[1]
        if v.startswith("www."):
            v = v[4:]
        if "." not in v:
            raise ValueError("Invalid domain format")
        return v


class CustomDomainResponse(BaseModel):
    domain: str
    verified: bool
    dns_instructions: str
    site_id: int


class UpdateSiteRequest(BaseModel):
    name: Optional[str] = None
    custom_domain: Optional[str] = None


# ─────────────────────────────────────────────
#  Analytics Schema
# ─────────────────────────────────────────────

class SiteAnalytics(BaseModel):
    site_id: int
    site_name: str
    view_count: int
    status: SiteStatus
    is_live: bool
    created_at: datetime
    deployed_at: Optional[datetime]


# Fix forward reference
Token.model_rebuild()
